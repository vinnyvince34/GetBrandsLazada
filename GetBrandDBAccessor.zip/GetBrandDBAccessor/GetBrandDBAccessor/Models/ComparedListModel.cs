﻿using GetBrandDBAccessor.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;

namespace GetBrandDBAccessor.Models
{
    public class ComparedListModel
    {
        public List<Module> MatchingItems { get; set; }
        public List<Module> DistinctItems { get; set; }
    }
}
