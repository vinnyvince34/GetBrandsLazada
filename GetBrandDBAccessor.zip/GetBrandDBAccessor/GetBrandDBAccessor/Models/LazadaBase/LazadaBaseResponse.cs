﻿using Newtonsoft.Json;

namespace iSeller.Members.SalesChannel.MarketPlace.Lazada.Model.OrderAPI.Response
{
    public class LazadaBaseResponse
    {
        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("request_id")]
        public string RequestID { get; set; }
    }
}
