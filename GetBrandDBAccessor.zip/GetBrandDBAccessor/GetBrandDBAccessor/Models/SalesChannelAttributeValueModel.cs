﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GetBrandDBAccessor.Models
{
    public class SalesChannelAttributeValueModel
    {
        public Guid AttributeValueId { get; set; }
        public string Provider { get; set; }
        public string Label { get; set; }
        public int Value { get; set; }
        public string AttributeId { get; set; }

    }
}
