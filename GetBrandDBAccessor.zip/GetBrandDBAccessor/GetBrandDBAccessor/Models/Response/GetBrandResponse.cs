﻿using iSeller.Members.SalesChannel.MarketPlace.Lazada.Model.OrderAPI.Response;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace GetBrandDBAccessor.Models.Response
{
    public class GetBrandResponse : LazadaBaseResponse
    {
        [JsonProperty("data")]
        public Data Data { get; set; }

        [JsonProperty("success")]
        public bool Success { get; set; }

        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("request_id")]
        public string RequestId { get; set; }
    }

    public class Data
    {
        [JsonProperty("enable_total")]
        public bool EnableTotal { get; set; }

        [JsonProperty("start_row")]
        public int StartRow { get; set; }

        [JsonProperty("page_index")]
        public int PageIndex { get; set; }

        [JsonProperty("module")]
        public List<Module> Module { get; set; }

        [JsonProperty("total_page")]
        public int TotalPage { get; set; }

        [JsonProperty("page_size")]
        public int PageSize { get; set; }

        [JsonProperty("total_record")]
        public int TotalRecord { get; set; }
    }

    public class Module
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("global_identifier")]
        public string GlobalIdentifier { get; set; }

        [JsonProperty("name_en")]
        public string NameEn { get; set; }

        [JsonProperty("brand_id")]
        public int BrandId { get; set; }
    }
}
