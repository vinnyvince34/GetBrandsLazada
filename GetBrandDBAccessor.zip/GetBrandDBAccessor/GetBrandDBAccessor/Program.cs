﻿using GetBrandDBAccessor.Models.Response;
using Lazop.Api;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System;
using GetBrandDBAccessor.Models;
using System.Linq;

namespace GetBrandDBAccessor
{
    class Program
    {
        private const string URL = "https://api.lazada.co.id/rest";
        private const int APP_KEY = 122259;
        private const string APP_SECRET = "QIBwUQ9ETEs6uXSNtXO5ocUnYOemYD8K";

        public static async Task<GetBrandResponse> GetBrandAsync(int offset, int limit)
        {
            ILazopClient client = new LazopClient(URL, APP_KEY.ToString(), APP_SECRET);
            LazopRequest request = new LazopRequest();
            request.SetApiName("/category/brands/query");
            request.SetHttpMethod("GET");
            request.AddApiParameter("startRow", offset.ToString());
            request.AddApiParameter("pageSize", limit.ToString());
            request.AddApiParameter("languageCode", "en_US");
            
            LazopResponse response = client.Execute(request);

            return JsonConvert.DeserializeObject<GetBrandResponse>(response.Body);
        }

        private static List<string> CompareList(List<Module> endpointResult, List<SalesChannelAttributeValueModel> databaseResult)
        {
            List<string> comparedList = new List<string>();
            foreach (var data in endpointResult)
            {
                SalesChannelAttributeValueModel matchedItem = databaseResult.Where(d => d.Label == data.Name).FirstOrDefault();
                if (matchedItem != null)
                {
                    comparedList.Add(matchedItem.Label);
                    Console.WriteLine("Match found: " + matchedItem.Label);
                }
            }

            return comparedList;
        }

        private static void InsertCommand(List<Module> endpointResult, List<SalesChannelAttributeValueModel> databaseResult, string connectionString)
        {
            using SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand();
            int dataSize = CountCommand(connectionString);

            for (int i = (dataSize < 1) ? 0 : dataSize; i < endpointResult.Count; i++)
            {
                Console.WriteLine($"Response: {i} -> {endpointResult[i].Name}");
                var guid = Guid.NewGuid();
                string brandName = endpointResult[i].Name;
                brandName = brandName.Replace("'", "");
                string queryInsert = $"INSERT INTO SalesChannelAttributeValues (AttributeValueId, Provider, Label, Value, AttributeId) VALUES ('{guid}', '{"lazada"}', '{brandName}', '{endpointResult[i].BrandId}', '{"brand"}')";

                command = new SqlCommand(queryInsert, connection);
                command.Connection.Open();
                command.ExecuteNonQuery();
                command.Connection.Close();
            }
        }

        private static int CountCommand(string connectionString)
        {
            using SqlConnection connection = new SqlConnection(connectionString);
            string queryInsert = "SELECT COUNT (*) FROM SalesChannelAttributeValues";
            int counter;

            SqlCommand command = new SqlCommand(queryInsert, connection);
            command.Connection.Open();
            counter = (int) command.ExecuteScalar();
            command.Connection.Close();

            return counter;
        }

        private static List<SalesChannelAttributeValueModel> GetAllBrandsFromDBCommand(string connectionString)
        {
            using SqlConnection connection = new SqlConnection(connectionString);
            string querySelect = "SELECT * FROM SalesChannelAttributeValues";
            List<SalesChannelAttributeValueModel> result = new List<SalesChannelAttributeValueModel>();

            SqlCommand command = new SqlCommand(querySelect, connection);
            command.Connection.Open();
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    SalesChannelAttributeValueModel tempData = new SalesChannelAttributeValueModel
                    {
                        AttributeValueId = Guid.Parse(reader["AttributeValueId"].ToString()),
                        Provider = reader["Provider"].ToString(),
                        Label = reader["Label"].ToString(),
                        Value = int.Parse(reader["Value"].ToString()),
                        AttributeId = reader["AttributeId"].ToString()
                    };
                    result.Add(tempData);
                    Console.WriteLine($"{tempData.Label} found");
                }
            }
            command.Connection.Close();

            return result;
        }

        static async Task Main(string[] args)
        {
            List<Module> responses = new List<Module>();
            int offset = 0;
            int limit = 200;
            int increment = 200;
            string connectionString = "Data Source=10.2.0.7;Initial Catalog=iSeller_System;Persist Security Info=True;User ID=domainadmin;Password=iSeller2016~";
            var dbExtractionResult = new List<SalesChannelAttributeValueModel>();
            var matchingData = new List<string>();

            Console.WriteLine("Initiating");
            Console.WriteLine("Press any key to continue");
            Console.ReadKey();

            do
            {
                Console.WriteLine($"Query: {offset}");
                GetBrandResponse result = await GetBrandAsync(offset, limit);
                foreach (var module in result.Data.Module)
                {
                    try
                    {
                        Console.WriteLine(module.GlobalIdentifier);
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
                responses.AddRange(result.Data.Module);
                if (responses.Count == result.Data.TotalRecord)
                {
                    Console.WriteLine("End of the data");
                    break;
                }
                offset += increment;
                limit += increment;
            } while (true);

            Console.WriteLine("Database extraction: starting up");
            try
            {
                dbExtractionResult = GetAllBrandsFromDBCommand(connectionString);
                Console.WriteLine("Database extraction: done");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine("Database matching data: starting up");
            try
            {
                matchingData = CompareList(responses, dbExtractionResult);
                Console.WriteLine("Database matching data: done");
                Console.WriteLine("Press any key to exit the program");
                Console.ReadKey();
                Environment.Exit(0);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Press any key to exit the program");
                Console.ReadKey();
                Environment.Exit(0);
            }

            //Console.WriteLine("Database insertion: starting up");
            //try
            //{
            //    InsertCommand(responses, dbExtractionResult, connectionString);

            //    Console.WriteLine($"Database insertion: 0 items");
            //    Console.WriteLine("Database insertion: done");
            //    Console.WriteLine("Press any key to exit the program");
            //    Console.ReadKey();
            //    Environment.Exit(0);
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //    Console.WriteLine("Press any key to exit the program");
            //    Console.ReadKey();
            //    Environment.Exit(0);
            //}
        }
    }
}
